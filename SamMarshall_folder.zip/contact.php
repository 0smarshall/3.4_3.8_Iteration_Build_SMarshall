<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Disconnected</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="./CSS/contact.css">
    <style>
        /* Basic styles for the page */
     
    
        /* Styles for the Back to Top Button */
        #backToTopBtn {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 15px;
            cursor: pointer;
            display: none; /* Hide the button by default */
            font-size: 16px;
        }
    
        #backToTopBtn:hover {
            background-color: #0056b3;
        }
    
        /* Content to make the page scrollable */
       
    </style>

</head>
<body>
    
<!-- header section starts  -->

<header class="header">

    <a href="#" class="logo">
        <img src="../v4/images/logo1.png" alt="">
    </a>

    <nav class="navbar">
        <a href="./index.html">home</a>
        <a href="./index.html#about">about</a>
        <a href="./product.html">products</a>
        <a href="./index.html#review">review</a>
        <a href="./contact.html">contact</a>
    </nav>

    <div class="icons">
        <div class="fas fa-search" id="search-btn"></div>
        <div class="fas fa-bars" id="menu-btn"></div>
    </div>

    <div class="search-form">
        <input type="search" id="search-box" placeholder="search here...">
        <label for="search-box" class="fas fa-search"></label>
    </div>

</header>

<!-- header section ends -->
 <!-- contact section srarts -->
<section class="contact" id="contact">
	<h1 class="heading">contact <span> us</span></h1>
 <div class="row">
	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3003.608378417754!2d174.82903877698033!3d-41.164896032892905!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d38accc90e953a3%3A0x233e7c6fb066360a!2sTawa%20College!5e0!3m2!1sen!2snz!4v1725843240378!5m2!1sen!2snz" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
	 <?php
    $error = NULL;
    ob_start();
    session_start();

			if($_SERVER["REQUEST_METHOD"] == "POST"){
					 require 'connectionfile.php';
			$name = mysqli_real_escape_string($conn, $_POST['name']);
			$email = mysqli_real_escape_string($conn, $_POST['email']);
			$phone = mysqli_real_escape_string($conn, $_POST['number']);

			$query = "INSERT INTO `messsages` (`name`, `number`, `email`) VALUES('$name', '$phone', '$email');";
			mysqli_query($conn, $query);
			header('Location' . $_SERVER['PHP_SELF']);}
	 ?>
	<form method="post">
		<h3>get in touch</h3>
		<div class="inputBox">
				<span class="fas fa-user"></span>
				<input type="text" name="name" placeholder="Name">
		</div>
		<div class="inputBox">
				<span class="fas fa-envelope"></span>
				<input type="text" name="email"placeholder="Email">
		</div>
		<div class="inputBox">
				<span class="fas fa-phone"></span>
				<input type="text" name="number" placeholder="Number">
		</div>
		<input type="submit" value="contact now" class="btn">
    </form>

   </div>
</section>
<!-- contact section sends -->
 <!-- footer section starts -->

<section class="footer">

	<div class="share">
        <a href="https://www.facebook.com/" class="fab fa-facebook-f"></a>
        <a href="https://www.bing.com/search?q=twitter&cvid=b65e71e96ce546569edd004a8f17962b&gs_lcrp=EgZjaHJvbWUyBggAEEUYOTIICAEQ6QcY_FXSAQczMDNqMGo5qAIAsAIB&FORM=ANAB01&DAF0=1&PC=U531" class="fab fa-twitter"></a>
        <a href="https://www.instagram.com/?hl=en" class="fab fa-instagram"></a>
        <a href="https://www.linkedin.com/" class="fab fa-linkedin"></a>
        <a href="https://nz.pinterest.com/" class="fab fa-pinterest"></a>
</div>

<div class="links">
    <a href="./index.html">home</a>
    <a href="./index.html#about">about</a>
    <a href="./product.html">products</a>
    <a href="./index.html#review">review</a>
    <a href="./contact.html">contact</a>	
</div>
	<div class="credit">
		created by 
		<span class="developer-info"> <a href="" target="">Samuel marshall</a></span> | all rights reserved <br> <br>
		 
	</div>
</section>
<!-- footer section ends -->

<!-- custom js file link  -->
<script>
// Get the button
const backToTopBtn = document.getElementById('backToTopBtn');

// Show the button when scrolling down 20px from the top of the document
window.onscroll = function() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        backToTopBtn.style.display = 'block';
    } else {
        backToTopBtn.style.display = 'none';
    }
};

// When the user clicks on the button, scroll to the top of the document
backToTopBtn.onclick = function() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
};
</script>

</body>
</html>